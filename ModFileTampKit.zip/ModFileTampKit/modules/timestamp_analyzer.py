# timestamp_analyzer.py
# Extracts file timestamps (creation, modification, access)

import os
import datetime

def get_file_timestamps(path):
    """
    Get timestamps of a given file.

    Args:
        path (str): Full file path.

    Returns:
        dict: Dictionary with 'created', 'modified', 'accessed' datetime objects.
        Empty dict if error occurs.
    """
    try:
        stats = os.stat(path)
        return {
            'created': datetime.datetime.fromtimestamp(stats.st_ctime),
            'modified': datetime.datetime.fromtimestamp(stats.st_mtime),
            'accessed': datetime.datetime.fromtimestamp(stats.st_atime)
        }
    except Exception as e:
        # Could log the error here if logger is integrated
        return {}
