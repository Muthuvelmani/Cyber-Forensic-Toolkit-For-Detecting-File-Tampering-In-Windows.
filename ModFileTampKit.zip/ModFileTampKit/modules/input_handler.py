# input_handler.py
# Handles user input for file/directory selection interactively

import os

def get_directory_path():
    """
    Prompt the user to enter a valid directory path for analysis.

    Returns:
        str: Validated directory path.
    """
    while True:
        path = input("Enter the full directory path for analysis: ").strip()
        if os.path.isdir(path):
            return path
        else:
            print(f"Error: '{path}' is not a valid directory. Please try again.\n")
