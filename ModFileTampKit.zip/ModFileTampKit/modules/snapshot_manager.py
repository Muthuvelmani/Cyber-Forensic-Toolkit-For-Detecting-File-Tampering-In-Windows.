# snapshot_manager.py
# Manages baseline snapshots for file integrity comparison

import json
import os

def save_snapshot(snapshot, path='data/baseline_snapshot.json'):
    """
    Save a snapshot (usually file hashes and metadata) to JSON file.

    Args:
        snapshot (dict): Dictionary containing file paths and their hashes/metadata.
        path (str): Path where to save the snapshot file.
    """
    # Ensure data directory exists
    os.makedirs(os.path.dirname(path), exist_ok=True)
    
    with open(path, 'w') as f:
        json.dump(snapshot, f, indent=4)

def load_snapshot(path='data/baseline_snapshot.json'):
    """
    Load a previously saved snapshot from JSON file.

    Args:
        path (str): Path of the snapshot file to load.

    Returns:
        dict: Loaded snapshot data, or empty dict if file doesn't exist or error occurs.
    """
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
