# hash_checker.py
# Handles file hashing and comparison logic

import os
import hashlib

def generate_file_hash(file_path):
    """
    Generate SHA-256 hash for a given file.

    Args:
        file_path (str): Path of the file to hash.

    Returns:
        str or None: Hex digest of SHA-256 hash, or None if error occurs.
    """
    try:
        with open(file_path, 'rb') as f:
            file_data = f.read()
            return hashlib.sha256(file_data).hexdigest()
    except Exception as e:
        # Could log exception e here for debugging (if logger used)
        return None

def scan_directory(directory):
    """
    Recursively scan a directory and generate hashes for all files.

    Args:
        directory (str): Root directory path to scan.

    Returns:
        dict: Mapping of file paths to their SHA-256 hashes.
    """
    file_hashes = {}

    for root, _, files in os.walk(directory):
        for file_name in files:
            path = os.path.join(root, file_name)
            hash_val = generate_file_hash(path)
            if hash_val:
                file_hashes[path] = hash_val

    return file_hashes
