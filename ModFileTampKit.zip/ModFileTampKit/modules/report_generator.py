# report_generator.py
# Generates comprehensive forensic reports

import json
import os
from datetime import datetime

def generate_report(changes, analysis_data=None, path='data/forensic_report.txt'):
    """
    Generate a comprehensive forensic analysis report.
    
    Args:
        changes (dict): Dictionary containing file changes categorized by status.
        analysis_data (dict): Additional analysis data like timestamps, hashes, etc.
        path (str): Output path for the report file.
    """
    # Ensure data directory exists
    os.makedirs(os.path.dirname(path), exist_ok=True)
    
    with open(path, 'w') as f:
        # Header
        f.write("=" * 60 + "\n")
        f.write("CYBER FORENSIC TOOLKIT - FILE TAMPERING REPORT\n")
        f.write("=" * 60 + "\n")
        f.write(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        # Summary section
        total_files = sum(len(files) for files in changes.values())
        f.write("EXECUTIVE SUMMARY:\n")
        f.write("-" * 20 + "\n")
        f.write(f"Total files analyzed: {total_files}\n")
        
        for status, files in changes.items():
            f.write(f"{status.upper()} files: {len(files)}\n")
        f.write("\n")
        
        # Detailed findings
        f.write("DETAILED FINDINGS:\n")
        f.write("-" * 20 + "\n")
        
        for status, files in changes.items():
            if files:  # Only show categories that have files
                f.write(f"\n{status.upper()} FILES ({len(files)}):\n")
                for file_path in files:
                    f.write(f"  - {file_path}\n")
        
        # Additional analysis data if provided
        if analysis_data:
            f.write("\nADDITIONAL ANALYSIS:\n")
            f.write("-" * 20 + "\n")
            f.write(json.dumps(analysis_data, indent=2, default=str))
        
        f.write("\n\n" + "=" * 60 + "\n")
        f.write("END OF REPORT\n")
        f.write("=" * 60 + "\n")

def generate_json_report(changes, analysis_data=None, path='data/forensic_report.json'):
    """
    Generate a machine-readable JSON forensic report.
    
    Args:
        changes (dict): Dictionary containing file changes categorized by status.
        analysis_data (dict): Additional analysis data.
        path (str): Output path for the JSON report.
    """
    # Ensure data directory exists
    os.makedirs(os.path.dirname(path), exist_ok=True)
    
    report_data = {
        'timestamp': datetime.now().isoformat(),
        'summary': {
            'total_files': sum(len(files) for files in changes.values()),
            'changes_by_category': {status: len(files) for status, files in changes.items()}
        },
        'detailed_findings': changes,
        'analysis_data': analysis_data or {}
    }
    
    with open(path, 'w') as f:
        json.dump(report_data, f, indent=4, default=str)
