# file_utils.py
# Utility functions for file system operations

import os

def list_all_files(directory):
    """
    Recursively list all files in a directory and its subdirectories.

    Args:
        directory (str): Root directory to traverse.

    Returns:
        list: List of full file paths found in the directory tree.
    """
    file_list = []
    
    for root, _, files in os.walk(directory):
        for file_name in files:
            file_list.append(os.path.join(root, file_name))
    
    return file_list

def get_file_size(file_path):
    """
    Get the size of a file in bytes.

    Args:
        file_path (str): Path to the file.

    Returns:
        int: File size in bytes, or 0 if error occurs.
    """
    try:
        return os.path.getsize(file_path)
    except OSError:
        return 0

def file_exists(file_path):
    """
    Check if a file exists and is accessible.

    Args:
        file_path (str): Path to check.

    Returns:
        bool: True if file exists, False otherwise.
    """
    return os.path.isfile(file_path)
