# log_parser.py
# Parses Windows Security Event Logs

import win32evtlog

def get_security_events():
    """
    Fetch security events from the local Windows Security Event Log.
    
    Returns:
        list of dicts: Each dict contains key event details such as time, source, ID, category, record number.
        Empty list if error occurs.
    """
    try:
        server = 'localhost'
        logtype = 'Security'
        hand = win32evtlog.OpenEventLog(server, logtype)
        flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ

        events = []
        events_list = win32evtlog.ReadEventLog(hand, flags, 0)

        for ev_obj in events_list:
            events.append({
                'TimeGenerated': ev_obj.TimeGenerated.Format(),
                'SourceName': ev_obj.SourceName,
                'EventID': ev_obj.EventID,
                'EventCategory': ev_obj.EventCategory,
                'RecordNumber': ev_obj.RecordNumber
            })

        return events

    except Exception as e:
        # Ideally log exception details for diagnostics
        return []
