# main.py
import os
from modules.input_handler import get_directory_path
from modules.hash_checker import scan_directory
from modules.timestamp_analyzer import get_file_timestamps
from modules.log_parser import get_security_events
from modules.snapshot_manager import save_snapshot, load_snapshot
from modules.file_utils import list_all_files
from modules.report_generator import generate_report, generate_json_report
from modules.logger import logger

def create_baseline():
    """
    Creates and saves a baseline snapshot of the current directory.
    """
    print("\n=== Creating Baseline Snapshot ===")
    dir_path = get_directory_path()
    print(f"Scanning directory: {dir_path}")
    hashes = scan_directory(dir_path)
    save_snapshot(hashes)
    print(f"Baseline saved with {len(hashes)} files.")
    logger.info(f"Baseline snapshot created for: {dir_path}")

def compare_with_baseline():
    """
    Compares current directory scan with saved baseline to detect changes.
    """
    print("\n=== Comparing with Baseline ===")
    baseline = load_snapshot()
    if not baseline:
        print("No baseline found. Please create a baseline first.")
        logger.warning("Attempted comparison without baseline.")
        return
    dir_path = get_directory_path()
    current_hashes = scan_directory(dir_path)
    changes = categorize_changes(baseline, current_hashes)
    print_changes_summary(changes)
    # Optional: Save report
    generate_report(changes)
    generate_json_report(changes)
    logger.info(f"Comparison completed for directory: {dir_path}")

def categorize_changes(baseline, current):
    """
    Detects added, deleted, modified, and unchanged files.
    Returns a dict categorizing files.
    """
    changes = {
        'added': [],
        'deleted': [],
        'modified': [],
        'unchanged': []
    }
    baseline_files = set(baseline.keys())
    current_files = set(current.keys())

    # Detect added files
    for file in current_files - baseline_files:
        changes['added'].append(file)

    # Detect deleted files
    for file in baseline_files - current_files:
        changes['deleted'].append(file)

    # Detect modified files
    for file in baseline_files & current_files:
        if baseline[file] != current[file]:
            changes['modified'].append(file)
        else:
            changes['unchanged'].append(file)

    return changes

def print_changes_summary(changes):
    """
    Prints a summary of detected changes.
    """
    print(f"\nFiles Added: {len(changes['added'])}")
    print(f"Files Deleted: {len(changes['deleted'])}")
    print(f"Files Modified: {len(changes['modified'])}")
    print(f"Files Unchanged: {len(changes['unchanged'])}")

def analyze_timestamps():
    """
    Analyzes timestamps of files in a chosen directory.
    """
    print("\n=== Timestamp Analysis ===")
    dir_path = get_directory_path()
    files = list_all_files(dir_path)
    print(f"Analyzing timestamps for {len(files)} files...")
    for file_path in files:
        timestamps = get_file_timestamps(file_path)
        print(f"\nFile: {file_path}")
        print(f"Created: {timestamps.get('created')}")
        print(f"Modified: {timestamps.get('modified')}")
        print(f"Accessed: {timestamps.get('accessed')}")
    logger.info(f"Timestamp analysis completed for: {dir_path}")

def parse_security_logs():
    """
    Fetches and displays recent Windows security event logs.
    """
    print("\n=== Parsing Windows Security Event Logs ===")
    events = get_security_events()
    print(f"Total Security Events Fetched: {len(events)}")
    for event in events[:10]:  # Show first 10 for brevity
        print(event)
    logger.info("Security event logs parsed.")

def main_menu():
    """
    User interface menu for selecting operations.
    """
    while True:
        print("\n--- Digital Forensics Toolkit ---")
        print("1. Create Baseline Snapshot")
        print("2. Compare Current State with Baseline")
        print("3. Analyze File Timestamps")
        print("4. Parse Windows Security Logs")
        print("5. Exit")
        choice = input("Select an option (1-5): ").strip()

        if choice == '1':
            create_baseline()
        elif choice == '2':
            compare_with_baseline()
        elif choice == '3':
            analyze_timestamps()
        elif choice == '4':
            parse_security_logs()
        elif choice == '5':
            print("Exiting. Stay safe!")
            logger.info("Program exited by user.")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == '__main__':
    print("=== Welcome to the Cyber Forensic Toolkit ===")
    logger.info("Program started.")
    main_menu()
    logger.info("Program terminated.")
