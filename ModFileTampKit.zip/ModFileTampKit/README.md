# Cyber Forensic Toolkit for Detecting File Tampering in Windows

A comprehensive digital forensics toolkit for detecting unauthorized file modifications, deletions, and additions on Windows systems.

## Features
- File hash-based integrity checking
- Baseline snapshot creation and comparison
- Timestamp analysis and timeline reconstruction
- Windows Security Event Log parsing
- Comprehensive forensic reporting

## Usage
